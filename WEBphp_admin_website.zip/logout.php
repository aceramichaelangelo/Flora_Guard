<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/init.php';

tg_session_start();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool)$p['secure'], (bool)$p['httponly']);
}
session_destroy();

header('Location: login.php', true, 302);
exit;
